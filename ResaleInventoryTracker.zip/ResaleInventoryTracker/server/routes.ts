import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import express from "express";
import multer from "multer";
import path from "path";
import fs from "fs";
import { storage } from "./storage";
import { insertInventoryItemSchema } from "@shared/schema";
import { z } from "zod";

// Configure multer for file uploads
const uploadsDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const upload = multer({
  storage: multer.diskStorage({
    destination: uploadsDir,
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
  }),
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(null, false);
    }
  },
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Serve uploaded files
  app.use('/uploads', (req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    next();
  }, express.static(uploadsDir));

  // Get all inventory items
  app.get('/api/inventory', async (req: Request, res: Response) => {
    try {
      const { search, category } = req.query;
      let items;
      
      if (search || category) {
        items = await storage.searchInventoryItems(
          (search as string) || '', 
          category as string
        );
      } else {
        items = await storage.getAllInventoryItems();
      }
      
      res.json(items);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch inventory items' });
    }
  });

  // Get single inventory item
  app.get('/api/inventory/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const item = await storage.getInventoryItem(id);
      
      if (!item) {
        return res.status(404).json({ message: 'Item not found' });
      }
      
      res.json(item);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch item' });
    }
  });

  // Create new inventory item with photo upload
  app.post('/api/inventory', upload.array('photos', 10), async (req: Request, res: Response) => {
    try {
      // Parse the form data
      const itemData = {
        name: req.body.name,
        category: req.body.category,
        subcategory: req.body.subcategory || null,
        purchaseDate: new Date(req.body.purchaseDate),
        location: req.body.location,
        cost: Math.round(parseFloat(req.body.cost) * 100), // Convert to cents
        estimatedValue: req.body.estimatedValue ? Math.round(parseFloat(req.body.estimatedValue) * 100) : undefined,
        notes: req.body.notes || '',
        photos: req.files && Array.isArray(req.files) 
          ? req.files.map(file => `/uploads/${file.filename}`)
          : [] as string[]
      };

      // Validate the data
      const validatedData = insertInventoryItemSchema.parse(itemData);
      
      // Create the item
      const newItem = await storage.createInventoryItem(validatedData);
      
      res.status(201).json(newItem);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: 'Validation error', 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: 'Failed to create item' });
    }
  });

  // Update inventory item
  app.put('/api/inventory/:id', upload.array('photos', 10), async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      const itemData: any = {
        name: req.body.name,
        category: req.body.category,
        subcategory: req.body.subcategory || null,
        purchaseDate: new Date(req.body.purchaseDate),
        location: req.body.location,
        cost: Math.round(parseFloat(req.body.cost) * 100),
        estimatedValue: req.body.estimatedValue ? Math.round(parseFloat(req.body.estimatedValue) * 100) : undefined,
        notes: req.body.notes || '',
      };

      // Handle photos - either keep existing or add new ones
      if (req.files && Array.isArray(req.files)) {
        itemData.photos = req.files.map(file => `/uploads/${file.filename}`);
      }

      const updatedItem = await storage.updateInventoryItem(id, itemData);
      
      if (!updatedItem) {
        return res.status(404).json({ message: 'Item not found' });
      }
      
      res.json(updatedItem);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update item' });
    }
  });

  // Delete inventory item
  app.delete('/api/inventory/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteInventoryItem(id);
      
      if (!deleted) {
        return res.status(404).json({ message: 'Item not found' });
      }
      
      res.json({ message: 'Item deleted successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete item' });
    }
  });

  // Get inventory statistics
  app.get('/api/stats', async (req: Request, res: Response) => {
    try {
      const stats = await storage.getInventoryStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch statistics' });
    }
  });

  // Export inventory data as CSV
  app.get('/api/export', async (req: Request, res: Response) => {
    try {
      const items = await storage.getAllInventoryItems();
      
      // CSV headers
      const headers = [
        'ID',
        'Item Name',
        'Category',
        'Purchase Date',
        'Purchase Location',
        'Purchase Cost',
        'Estimated Resale Value',
        'Estimated Profit',
        'Notes'
      ];

      // Convert items to CSV rows
      const rows = items.map(item => [
        item.id.toString(),
        `"${item.name.replace(/"/g, '""')}"`,
        item.category,
        new Date(item.purchaseDate).toLocaleDateString(),
        `"${item.location.replace(/"/g, '""')}"`,
        `$${(item.cost / 100).toFixed(2)}`,
        item.estimatedValue ? `$${(item.estimatedValue / 100).toFixed(2)}` : '',
        item.estimatedValue ? `$${((item.estimatedValue - item.cost) / 100).toFixed(2)}` : '',
        item.notes ? `"${item.notes.replace(/"/g, '""')}"` : ''
      ]);

      // Combine headers and rows
      const csv = [headers.join(','), ...rows.map(row => row.join(','))].join('\n');

      // Set response headers for file download
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="inventory-export-${new Date().toISOString().split('T')[0]}.csv"`);
      
      res.send(csv);
    } catch (error) {
      res.status(500).json({ message: 'Failed to export data' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
