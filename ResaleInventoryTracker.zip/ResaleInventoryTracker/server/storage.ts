import { inventoryItems, type InventoryItem, type InsertInventoryItem } from "@shared/schema";
import { db } from "./db";
import { eq, ilike, or, and, desc } from "drizzle-orm";

export interface IStorage {
  // Inventory Items
  getAllInventoryItems(): Promise<InventoryItem[]>;
  getInventoryItem(id: number): Promise<InventoryItem | undefined>;
  createInventoryItem(item: InsertInventoryItem): Promise<InventoryItem>;
  updateInventoryItem(id: number, updates: Partial<InsertInventoryItem>): Promise<InventoryItem | undefined>;
  deleteInventoryItem(id: number): Promise<boolean>;
  searchInventoryItems(query: string, category?: string): Promise<InventoryItem[]>;
  
  // Statistics
  getInventoryStats(): Promise<{
    totalItems: number;
    totalValue: number;
    estimatedProfit: number;
    categories: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  async getAllInventoryItems(): Promise<InventoryItem[]> {
    const items = await db.select().from(inventoryItems).orderBy(desc(inventoryItems.purchaseDate));
    return items;
  }

  async getInventoryItem(id: number): Promise<InventoryItem | undefined> {
    const [item] = await db.select().from(inventoryItems).where(eq(inventoryItems.id, id));
    return item || undefined;
  }

  async createInventoryItem(insertItem: InsertInventoryItem): Promise<InventoryItem> {
    const [item] = await db
      .insert(inventoryItems)
      .values(insertItem)
      .returning();
    return item;
  }

  async updateInventoryItem(id: number, updates: Partial<InsertInventoryItem>): Promise<InventoryItem | undefined> {
    const [item] = await db
      .update(inventoryItems)
      .set(updates)
      .where(eq(inventoryItems.id, id))
      .returning();
    return item || undefined;
  }

  async deleteInventoryItem(id: number): Promise<boolean> {
    const result = await db.delete(inventoryItems).where(eq(inventoryItems.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async searchInventoryItems(query: string, category?: string): Promise<InventoryItem[]> {
    let whereConditions = [];

    if (query && query.trim() !== '') {
      const searchCondition = or(
        ilike(inventoryItems.name, `%${query}%`),
        ilike(inventoryItems.location, `%${query}%`),
        ilike(inventoryItems.notes, `%${query}%`)
      );
      whereConditions.push(searchCondition);
    }

    if (category && category.trim() !== '') {
      whereConditions.push(eq(inventoryItems.category, category));
    }

    const whereClause = whereConditions.length > 0 ? and(...whereConditions) : undefined;

    const items = await db
      .select()
      .from(inventoryItems)
      .where(whereClause)
      .orderBy(desc(inventoryItems.purchaseDate));

    return items;
  }

  async getInventoryStats(): Promise<{
    totalItems: number;
    totalValue: number;
    estimatedProfit: number;
    categories: number;
  }> {
    const items = await this.getAllInventoryItems();
    
    const totalItems = items.length;
    const totalValue = items.reduce((sum, item) => sum + item.cost, 0);
    const estimatedProfit = items.reduce((sum, item) => {
      const estimatedValue = item.estimatedValue || 0;
      return sum + (estimatedValue - item.cost);
    }, 0);

    const uniqueCategories = new Set(items.map(item => item.category));
    const categories = uniqueCategories.size;

    return {
      totalItems,
      totalValue,
      estimatedProfit,
      categories,
    };
  }
}

export const storage = new DatabaseStorage();
