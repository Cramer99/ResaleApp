import { useState } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Sidebar } from "@/components/layout/sidebar";
import { Header } from "@/components/layout/header";
import { useIsMobile } from "@/hooks/use-mobile";
import Dashboard from "@/pages/dashboard";
import Inventory from "@/pages/inventory";
import AddItem from "@/pages/add-item";
import Export from "@/pages/export";
import NotFound from "@/pages/not-found";

function getPageTitle(pathname: string): string {
  switch (pathname) {
    case "/":
      return "Dashboard";
    case "/inventory":
      return "Inventory Items";
    case "/add-item":
      return "Add New Item";
    case "/export":
      return "Export Data";
    default:
      return "Page Not Found";
  }
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/inventory" component={Inventory} />
      <Route path="/add-item" component={AddItem} />
      <Route path="/export" component={Export} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const isMobile = useIsMobile();
  const currentPath = window.location.pathname;

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="min-h-screen flex bg-gray-50">
          <Sidebar
            isOpen={isMobile ? mobileMenuOpen : true}
            onClose={() => setMobileMenuOpen(false)}
            isMobile={isMobile}
          />
          
          <div className="flex-1 flex flex-col">
            <Header
              title={getPageTitle(currentPath)}
              onMobileMenuToggle={() => setMobileMenuOpen(true)}
            />
            
            <main className="flex-1 p-6">
              <Router />
            </main>
          </div>
        </div>
        
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
