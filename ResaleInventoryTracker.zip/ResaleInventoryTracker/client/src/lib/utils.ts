import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(cents: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(cents / 100);
}

export function formatDate(date: string | Date): string {
  return new Date(date).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

export function calculateProfit(cost: number, estimatedValue?: number): number {
  if (!estimatedValue) return 0;
  return estimatedValue - cost;
}

export function getCategoryColor(category: string): string {
  const colors = {
    clothing: 'bg-blue-100 text-blue-800',
    electronics: 'bg-green-100 text-green-800',
    'home-garden': 'bg-purple-100 text-purple-800',
    books: 'bg-yellow-100 text-yellow-800',
    toys: 'bg-pink-100 text-pink-800',
    collectibles: 'bg-indigo-100 text-indigo-800',
    other: 'bg-gray-100 text-gray-800',
  };
  return colors[category] || colors.other;
}
