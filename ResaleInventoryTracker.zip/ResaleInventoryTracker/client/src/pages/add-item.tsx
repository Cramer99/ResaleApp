import { ItemForm } from "@/components/inventory/item-form";

export default function AddItem() {
  return <ItemForm />;
}
