import { InventoryTable } from "@/components/inventory/inventory-table";

export default function Inventory() {
  return <InventoryTable />;
}
