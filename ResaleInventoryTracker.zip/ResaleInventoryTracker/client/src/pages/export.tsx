import { useState } from "react";
import { Download, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";

export default function Export() {
  const [format, setFormat] = useState("csv");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [isExporting, setIsExporting] = useState(false);
  const { toast } = useToast();

  const [includedColumns, setIncludedColumns] = useState({
    name: true,
    category: true,
    purchaseDate: true,
    location: true,
    cost: true,
    estimatedValue: true,
    profit: true,
    notes: false,
  });

  const handleColumnToggle = (column: string) => {
    setIncludedColumns(prev => ({
      ...prev,
      [column]: !prev[column],
    }));
  };

  const handleExport = async () => {
    setIsExporting(true);
    
    try {
      // Build query parameters
      const params = new URLSearchParams();
      if (startDate) params.append('startDate', startDate);
      if (endDate) params.append('endDate', endDate);
      
      // Make the export request
      const response = await fetch(`/api/export?${params}`);
      
      if (!response.ok) {
        throw new Error('Export failed');
      }

      // Create blob and download
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = url;
      a.download = `inventory-export-${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast({
        title: "Success",
        description: "Inventory data exported successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to export data",
        variant: "destructive",
      });
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <Card>
        <CardHeader>
          <CardTitle>Export Inventory Data</CardTitle>
          <p className="text-sm text-gray-600">Download your inventory data for use in spreadsheets</p>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <Label className="text-sm font-medium mb-3 block">Export Format</Label>
            <RadioGroup value={format} onValueChange={setFormat}>
              <div className="space-y-3">
                <div className="flex items-start space-x-3">
                  <RadioGroupItem value="csv" id="csv" className="mt-0.5" />
                  <div className="grid gap-1.5 leading-none">
                    <Label htmlFor="csv" className="text-sm font-medium">
                      CSV (Comma-separated values)
                    </Label>
                    <p className="text-sm text-gray-500">
                      Compatible with Excel, Google Sheets, and most spreadsheet applications
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <RadioGroupItem value="xlsx" id="xlsx" className="mt-0.5" />
                  <div className="grid gap-1.5 leading-none">
                    <Label htmlFor="xlsx" className="text-sm font-medium">
                      Excel (.xlsx)
                    </Label>
                    <p className="text-sm text-gray-500">
                      Native Excel format with formatting preserved
                    </p>
                  </div>
                </div>
              </div>
            </RadioGroup>
          </div>

          <div>
            <Label className="text-sm font-medium mb-3 block">Include Columns</Label>
            <div className="space-y-2">
              {Object.entries(includedColumns).map(([column, checked]) => (
                <div key={column} className="flex items-center space-x-2">
                  <Checkbox
                    id={column}
                    checked={checked}
                    onCheckedChange={() => handleColumnToggle(column)}
                  />
                  <Label htmlFor={column} className="text-sm">
                    {column === 'name' && 'Item Name'}
                    {column === 'category' && 'Category'}
                    {column === 'purchaseDate' && 'Purchase Date'}
                    {column === 'location' && 'Purchase Location'}
                    {column === 'cost' && 'Purchase Cost'}
                    {column === 'estimatedValue' && 'Estimated Resale Value'}
                    {column === 'profit' && 'Estimated Profit'}
                    {column === 'notes' && 'Notes'}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <div>
            <Label className="text-sm font-medium mb-3 block">Date Range (Optional)</Label>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="start-date" className="text-xs text-gray-500 mb-1 block">
                  From Date
                </Label>
                <Input
                  type="date"
                  id="start-date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="end-date" className="text-xs text-gray-500 mb-1 block">
                  To Date
                </Label>
                <Input
                  type="date"
                  id="end-date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                />
              </div>
            </div>
          </div>

          <div className="bg-blue-50 rounded-lg p-4">
            <div className="flex items-start space-x-3">
              <Info className="text-blue-600 mt-0.5 h-5 w-5" />
              <div className="text-sm text-blue-800">
                <strong>Export Summary:</strong> Your export will include all inventory items based on your selected filters. The file will be automatically downloaded to your device.
              </div>
            </div>
          </div>

          <div className="flex justify-end space-x-4 pt-6 border-t">
            <Button variant="outline">
              Cancel
            </Button>
            <Button onClick={handleExport} disabled={isExporting}>
              <Download className="w-4 h-4 mr-2" />
              {isExporting ? "Exporting..." : "Export Data"}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
