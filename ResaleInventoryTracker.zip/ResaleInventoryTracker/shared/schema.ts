import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const inventoryItems = pgTable("inventory_items", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  category: text("category").notNull(),
  subcategory: text("subcategory"),
  purchaseDate: timestamp("purchase_date").notNull(),
  location: text("location").notNull(),
  cost: integer("cost").notNull(), // stored in cents
  estimatedValue: integer("estimated_value"), // stored in cents
  notes: text("notes"),
  photos: text("photos").array().default([]), // array of photo URLs/paths
});

export const insertInventoryItemSchema = createInsertSchema(inventoryItems, {
  cost: z.number().min(0),
  estimatedValue: z.number().min(0).nullable().optional(),
  purchaseDate: z.date(),
  photos: z.array(z.string()).default([]),
}).omit({ id: true });

export type InsertInventoryItem = z.infer<typeof insertInventoryItemSchema>;
export type InventoryItem = typeof inventoryItems.$inferSelect;

// Categories enum for frontend
export const CATEGORIES = [
  'clothing',
  'electronics', 
  'home-garden',
  'books',
  'toys',
  'collectibles',
  'other'
] as const;

export type Category = typeof CATEGORIES[number];

// Subcategories for clothing
export const CLOTHING_SUBCATEGORIES = [
  'shirt',
  'pants',
  'dress',
  'sweater',
  'misc',
  'accessory',
  'other'
] as const;

export type ClothingSubcategory = typeof CLOTHING_SUBCATEGORIES[number];
